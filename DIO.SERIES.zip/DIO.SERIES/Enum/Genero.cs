namespace DIO.Series  
{
  public enum Genero
  {
    Acao = 1,
    Aventura = 2,
    Comedia = 3,
    Documentario = 4,
    Drama = 5,
    Espionagem = 6,
    Faroeste = 7,
    Ficcao_Cientifica = 8,
    Romance = 9,
    Suspense = 10,
    Terror = 11,
 
  }

}